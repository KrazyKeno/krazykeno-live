// placeholder for blackjack data table
