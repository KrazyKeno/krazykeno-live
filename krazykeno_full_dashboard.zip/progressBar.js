// placeholder for live progress bar
